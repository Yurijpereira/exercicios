#include <stdio.h>

/*
Yuri J. Pereira
exe_01. Declarar um conjunto de vari�veis inteiras, reais e char.
*/

int main (void){

    int inteiro1=1, inteiro2=2, inteiro3=3;
    float real1=1, real2=2, real3=3;
    char char1='1', char2='2', char3='3';

    printf("Inteiro: %i\nInteiro: %i\nInteiro: %i\nReal: %f\nReal: %f\nReal: %f\nChar: %c\nChar: %c\nChar: %c", inteiro1, inteiro2, inteiro3, real1, real2, real3, char1, char2, char3);

    return 0;
}
